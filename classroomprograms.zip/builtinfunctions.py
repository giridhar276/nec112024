print(list(range(1,10)))  # range()

val = 10
print(type(val))
print(isinstance(10,int))
print(isinstance(10,float))
alist = [10,20,30]
print(type(alist))
print(isinstance(alist,list))
print(isinstance(alist,tuple))


name = input("Enter any name :")
print("you entered :",name)

print(max(alist))
print(min(alist))
print(sum(alist))

atup = (10,20,30)
alist = list(atup)
alist.append(40)
atup = tuple(alist)
print("Afte changes :",atup)