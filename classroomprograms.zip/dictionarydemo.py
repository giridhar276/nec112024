book = {"chap1":10 ,"chap2":20,"chap3":30}

print(book)
print(book["chap1"])

# creating new key value
book["chap4"] = 40
book["chap5"] = 50
print(book)

#methods
print(book.keys())  # display keys

for key in book.keys():
    print(key)

# display values
print(book.values()) # display values

for value in book.values():
    print(value)

# display key-values
print(book.items())

for key,value in book.items():
    print(key,value)

# remove key-value
book.pop("chap1")
print("After pop :",book)

book.popitem()
print("After popitem",book)

print(book.get("chap10")) # if not  existing it returns None ... safer side

if "chap10" in book:
    print(book["chap10"])
else:
    print("key doesnt exist")


newbook = {"chap11":110,"chap12":120}
#method1
book.update(newbook)
print(book) #book is getting updated
#method2
finalbook ={**book,**newbook}
print(finalbook)

