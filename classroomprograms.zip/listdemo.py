alist = [45,67,12,83,78,82]
# slicing
print(alist[0:5])
# methods
print(alist)
alist.append(100)
print("After appending :",alist)

alist.extend([51,45,19,95])
print("After extending :",alist)

alist.insert(1,25)  # list.insert(index,value)
print("After inserting :",alist)

alist.pop(3) #12 will be removed from index 3
print("After pop :",alist)

alist.remove(100000) # 100 will be removed
print("After remove :",alist)

alist.reverse()
print("Reversing list :",alist)

alist.sort()
print("sorting in ascending order:",alist)

alist.sort(reverse=True)
print("descending order:",alist)


print("count of 45:",alist.count(45))

print(alist[4]) #

print(alist.index(45))





alist = [10,20,30,40,50]
if 100 in alist:
    alist.remove(100)
    print(alist)


for val in alist:
    print(val)


#display list in reverse order
for val in alist[::-1]:
    print(val)