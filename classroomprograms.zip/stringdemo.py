name = "python programming"
print(name)
print("I love",name)

#p   y   t   h   o    n     p    r    o   g  r  a   m   m  i    n    g
#0   1    2     3   4    5  6   7    8  
#                                               -6   -5  -4 -3   -2   -1
# slicing
#string[start:stop:step]
print(name[4])
print(name[14])
print(name[0:4])
print(name[0:4:2])  #pt
print(name[9:11])
print(name[9:11:1])
print(name[0:18:2])
print(name[9:16:4])
print(name[::])   # from beginning to ending with step 1
print(name[:])
print(name[-1])
print(name[-2])
print(name[-6:-3])
print(name[::-1])

# string is immutable  # unchangeable
name = "python programming"
#name = name.upper()  # to make the changes permanent
print(name)
print(name.capitalize())
print(name.title())
print(name.center(40))
print(name.center(40,"*"))
print(name.count("P"))
print(name.count("p"))
print(name.count("P".lower()))
print(name.replace("python","java"))
print(name)  # original string remains same as it is .
output = name.split(" ")
print(output)
print(name.startswith("p"))
print(name.startswith("P"))
aname = "  python    "
print(len(aname))
print(len(aname.strip())) # remove whitespaces at both the ends
print(len(aname.lstrip()))# only at the left side
print(len(aname.rstrip())) # only at right side
print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.index('y'))
print(name.find("ing"))
print(name.find("abc"))


if name.isupper():
    print("sstring is upper")

# simpel if
if name.startswith("p"):
    print("Its python programing")

# if-else
if name.startswith("p"):
    print("Its python programing")
else:
    print("java programming")

# if-elif-elif-elif-else
if name.startswith("p"):
    print("Its python programing")
elif name.startswith("j"):
    print("java programming")
elif name.startswith("r"):
    print("ruby programming")
else:
    print("Its someother language")



# range(start,stop,step)
for i in range(1,11): # excluding 11
    print(i)

# range(start,stop,step)
for i in range(2,10,2): # excluding 11
    print(i)

for val in range(1,10,5):
    print(val)   #1  6

name = "python"
for char in name :
    print(char)

alist = [10,20,30,40]
for val in alist:
    print(val)

for val in alist[::-1]:
    print(val)