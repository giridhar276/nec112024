

#fixed arguments
def display(a,b):
    c = a + b
    return c
total = display(10,20) 
print(total)




# lambda is replacment of single liner function
# Instead of writing function body , we simply define lambda function
#syntax
#functioname = lambda variables:expression
# the expression will be replaced in the caling function

display = lambda x,y: x + y
total = display(10,20)
print(total)

square = lambda x: x**2
print(square(5))


checkgreatest = lambda x,y : x if x >y else y
print(checkgreatest(10,15))


checkeligible = lambda age : "Eligible" if age >=18 else   "Not eligble"
print(checkeligible(20))
print(checkeligible(12))



# when to use map() ?  If you are looking for updating list then use map()
#map(function,iterable)
alist = [10,15,20]

#output
[15,20,25]
#method1
blist =[]
for val in alist:
    blist.append(val + 5)
print(blist)


#method2
#map(function,iterable)
alist = [10,15,20]
def increment(x):
    return x + 5
print(list(map(increment,alist)))


print(list(map(lambda x : x+5,alist)))


data = ["python","unix","java"]
print(list(map(lambda x: x + " programming", data)))