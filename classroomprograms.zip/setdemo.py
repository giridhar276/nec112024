

aset= {10,10,20,20,30,40,40,40}
bset = {40,40,40,50,60,70}

print(aset)
print(bset)

print("union :", aset.union(bset))

print("Intersetction :", aset.intersection(bset))

print("differentce :", aset.difference(bset))