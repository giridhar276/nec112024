#fixed arguments
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)

# default arguments
def display(a = 0,b =0 ,c = 0,d = 0):
    print(a,b,c,d)
display()
display(10)
display(10,20)
display(10,20,30)
display(10,20,30,40)

# if any object starts with * , it is treated as tuple
def display(*args):
    for val in args:
        print(val)
    print("Sum :",sum(args))
display(10,20,30,40,7,543,67,54,67,43,56,3,5,67,54,678,43,5643,4,56,43,65,1)

def displaydata(**kwargs):
    print(kwargs)
    for key,value in kwargs.items():
        print(key,value)
displaydata(chap1 = 10 ,chap2 =20)





