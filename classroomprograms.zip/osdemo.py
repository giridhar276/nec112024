

import os

#os.remove("candelete.txt")


for file in os.listdir():
    print(file)


import shutil # shell utilities



import cx_Oracle