

alist = [10,20,30]
alist[0] = 100
print(alist)

atup = (20,320,30)
atup[0] = 200
print(atup)